package com.robotvinay.garbage_collector

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
